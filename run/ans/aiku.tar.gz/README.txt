tar file contains anwers for two cross-level similarity tasks.

p2s -> paragraph2sentence
s2p -> sentence2phrase

s1 -> system1 answers
s2 -> system2 answers
