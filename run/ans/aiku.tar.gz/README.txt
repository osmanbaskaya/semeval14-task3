TEAM ID: AIKU
Team affiliation: KOC UNIVERSITY, Istanbul, Turkey.
Contact: Osman Baskaya, obaskaya@ku.edu.tr


System 1 utilizes the co-occurrence statistics (with S-CODE)
on raw test data. 

System 2 utilizes the co-occurrence statistics again but this 
time, its input is not raw test data, subsitutites of each word
according the context that occur.

Both systems are unsupervised.

Submission Information:

tar file contains anwers for two cross-level similarity tasks.

p2s -> paragraph2sentence
s2p -> sentence2phrase

s1 -> system1 answers
s2 -> system2 answers
